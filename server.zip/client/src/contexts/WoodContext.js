import { createContext } from 'react';

export const WoodContext = createContext();
